                



<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center text-primary"><?php echo e($researchGroup->title ?? ''); ?></h2>
    <h4 class="text-center text-dark"><?php echo e($researchGroup->subtitle ?? ''); ?></h4>
    <div class="card p-4 mt-4">
        <h3 class="text-dark">Research rationale ของกลุ่มวิจัย</h3>
        <p><?php echo e($researchGroup->rationale ?? ''); ?></p>
    </div>

    <div class="card p-4 mt-4">
        <h3 class="text-dark">หัวข้อวิจัยที่เป็นจุดเด่นของกลุ่ม</h3>
        <ul>
            <?php $__currentLoopData = $researchGroup->topics ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <h3 class="card-text"><?php echo e($topic->{'group_detail_'.app()->getLocale()}); ?>

                    </h3>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="card p-4 mt-4">
        <h3 class="text-dark">สมาชิกของกลุ่มวิจัย</h3>
        <h5>หัวหน้ากลุ่มวิจัย</h5>
        <p><?php echo e($researchGroup->leader ?? ''); ?></p>
        <h5>สมาชิก</h5>
        <ul>
            <?php $__currentLoopData = $researchGroup->members ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($member); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="text-center mt-4">
        <img src="<?php echo e(asset($researchGroup->contact_image ?? 'img/1648184069.png')); ?>" alt="Contact Person" class="rounded-circle" width="150">
        <p>Contact person <?php echo e($researchGroup->user ?? ''); ?>, <?php echo e($researchGroup->contact_email ?? ''); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Project_2-master\Project_2-master\resources\views/researchgroupdetail.blade.php ENDPATH**/ ?>