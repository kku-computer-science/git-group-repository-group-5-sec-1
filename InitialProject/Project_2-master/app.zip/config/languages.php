
<?php

return [
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ],
    'th' => [
        'display' => 'ไทย',
        'flag-icon' => 'th'
    ],
    
];
